// Shared header menu behavior is owned by assets/js/partials.js.
const yearEl = document.querySelector("#year");
if (yearEl) yearEl.textContent = new Date().getFullYear();

document.querySelectorAll(".package-carousel-shell").forEach((shell) => {
  const carousel = shell.querySelector(".package-carousel");
  const cards = carousel?.querySelectorAll(".price-card");
  if (!carousel || !cards?.length) return;
  const controls = [...shell.querySelectorAll("[data-carousel-direction]")];
  const status = shell.querySelector(".carousel-status");
  const updateCarouselState = () => {
    const maxScroll = carousel.scrollWidth - carousel.clientWidth;
    const atStart = carousel.scrollLeft <= 2;
    const atEnd = carousel.scrollLeft >= maxScroll - 2;
    controls.forEach((button) => {
      const isNext = button.dataset.carouselDirection === "next";
      button.disabled = isNext ? atEnd : atStart;
      button.setAttribute("aria-disabled", String(button.disabled));
    });
    const step = cards[0].getBoundingClientRect().width + 18;
    const current = Math.min(
      cards.length,
      Math.max(1, Math.round(carousel.scrollLeft / step) + 1),
    );
    if (status) status.textContent = `Package ${current} of ${cards.length}`;
  };
  controls.forEach((button) =>
    button.addEventListener("click", () => {
      const direction = button.dataset.carouselDirection === "next" ? 1 : -1;
      const distance = cards[0].getBoundingClientRect().width + 18;
      carousel.scrollBy({ left: direction * distance, behavior: "smooth" });
    }),
  );
  carousel.addEventListener("scroll", updateCarouselState, { passive: true });
  window.addEventListener("resize", updateCarouselState);
  updateCarouselState();
});

// Keep same-page navigation reliable during local preview and on the live site.
document.querySelectorAll('a[href^="#"]').forEach((a) =>
  a.addEventListener("click", (e) => {
    const id = a.getAttribute("href").slice(1);
    const target = document.getElementById(id);
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView({ behavior: "smooth", block: "start" });
    try {
      history.replaceState(null, "", "#" + id);
    } catch (_) {}
  }),
);

const form = document.querySelector("#leadForm");
const formHelp = document.querySelector("#formHelp");
const submitBtn = form?.querySelector('button[type="submit"]');
const packageSelect = document.querySelector("#packageSelect");

// Single source of truth for inquiry categories, package choices and indicative pricing.
// Keep the package IDs unchanged for compatibility with existing CTA links and inquiry backend.
const POSE_PACKAGES = [
  ['Photobooth 4R', 'Classic Photobooth', 2999, 1000, '4R Photobooth · ₱2,999'],
  ['Photobooth Strip', 'Classic Photobooth', 3499, 1000, 'Strip Photobooth · ₱3,499'],
  ['Strip Souvenir 50', 'Classic Photobooth', 5999, 1000, 'Souvenir Bundle · Strip + 50 Keychains · ₱5,999'],
  ['Strip Souvenir 100', 'Classic Photobooth', 7499, 1000, 'Souvenir Bundle · Strip + 100 Keychains · ₱7,499'],
  ['Strip Magnetic Souvenir 50', 'Classic Photobooth', 6499, 1000, 'Souvenir Bundle · Strip + 50 Magnetic Sets · ₱6,499'],
  ['Strip Magnetic Souvenir 100', 'Classic Photobooth', 8499, 1000, 'Souvenir Bundle · Strip + 100 Magnetic Sets · ₱8,499'],
  ['Photobooth Dedication', 'Classic Photobooth', 3499, 1000, 'Dedication Photobooth · ₱3,499'],
  ['Photobooth Polaroid', 'Classic Photobooth', 3999, 1500, 'Polaroid Photobooth · ₱3,999'],
  ['Signature Booth', 'Signature Photobooth', 4999, 1500, 'Signature Photobooth · ₱4,999'],
  ['Photoman Unlimited', 'Photoman', 4999, 1500, 'Photoman Unlimited · ₱4,999'],
  ['Photoman Premium', 'Photoman', 7499, 2000, 'Photoman Premium · ₱7,499'],
  ['360 Package', '360 Video Booth', 12000, 2000, '360 Video Booth · ₱12,000'],
  ['Trading Card Photobooth', 'Trading Card Photobooth', 9999, 2000, 'Trading Card Photobooth · ₱9,999'],
  ['Studio Promo', 'On-site Photo Studio', 8000, 1500, 'On-site Photo Studio · ₱8,000'],
  ['AI Essential', 'AI Photobooth', 7499, null, 'AI Essential · 2 hours · Up to 75 AI portraits · ₱7,499'],
  ['AI Premium', 'AI Photobooth', 9999, 2000, 'AI Premium · 3 hours · Up to 150 AI portraits · ₱9,999'],
  ['Help Me Choose', 'Not sure yet', null, null, 'Help me choose a package']
].map(([id, category, price, extraHourRate, label]) => ({id, category, price, extraHourRate, label}));
const posePackageById = new Map(POSE_PACKAGES.map(p => [p.id, p]));
const packageServices = Object.fromEntries(POSE_PACKAGES.map(p => [p.id, p.category]));
const serviceSelect = form?.querySelector('[name="service"]');
const packageHint = document.getElementById('packageHint');
function populatePackages(category, selectedId = '') {
  if (!packageSelect) return;
  packageSelect.replaceChildren();
  const options = POSE_PACKAGES.filter(p => p.category === category);
  if (!options.length) {
    packageSelect.add(new Option('Choose a service category first', ''));
    packageSelect.disabled = true;
    if (packageHint) packageHint.textContent = 'Select a service above to view packages.';
    packageSelect.dispatchEvent(new Event('change', {bubbles:true}));
    return;
  }
  packageSelect.disabled = false;
  packageSelect.add(new Option('Select a package', ''));
  options.forEach(p => packageSelect.add(new Option(p.label, p.id)));
  packageSelect.value = options.some(p=>p.id === selectedId) ? selectedId : (category === 'Not sure yet' ? 'Help Me Choose' : '');
  if (packageHint) packageHint.textContent = category === 'Not sure yet'
    ? 'Tell us about your event and POSE will recommend a package.'
    : `${options.length} available ${options.length === 1 ? 'package' : 'packages'} for ${category}.`;
  packageSelect.dispatchEvent(new Event('change', {bubbles:true}));
}
function selectPosePackage(id) {
  if (id === 'AI Photobooth') id = 'AI Essential'; // Legacy homepage links.
  const p = posePackageById.get(id);
  if (!p || !serviceSelect) return false;
  serviceSelect.value = p.category;
  populatePackages(p.category, id);
  return true;
}
serviceSelect?.addEventListener('change', () => populatePackages(serviceSelect.value));
// CTA and finder links may be inserted dynamically; delegate clicks to preserve their selections.
document.addEventListener('click', e => {
  const link = e.target.closest('[data-package], [data-addon]');
  if (!link) return;
  if (link.dataset.addon) {
    const checkbox = document.getElementById({video:'addonVideoGuestbook',projector:'addonProjector',photography:'addonPhotography'}[link.dataset.addon]);
    if (checkbox && !checkbox.disabled) {
      checkbox.checked = true;
      checkbox.dispatchEvent(new Event('change', {bubbles:true}));
      if (packageHint) packageHint.textContent = 'Add-on selected. Review your estimated total below.';
    } else if (packageHint) {
      packageHint.textContent = 'Select your main POSE service and package first, then choose this add-on.';
    }
    checkbox?.focus();
    return;
  }
  const selected = selectPosePackage(link.dataset.package);
  if (selected && link.dataset.addPhotography === 'true') {
    const photography = document.getElementById('addonPhotography');
    if (photography && !photography.disabled) {photography.checked = true; photography.dispatchEvent(new Event('change', {bubbles:true}));}
  }
  if (selected && link.dataset.souvenir) {
    const souvenir = document.getElementById('quoteSouvenir');
    if (souvenir && !souvenir.disabled) {
      souvenir.value = link.dataset.souvenir;
      souvenir.dispatchEvent(new Event('change', {bubbles:true}));
    }
  }
});
populatePackages(serviceSelect?.value || '');
form?.addEventListener('reset', () => setTimeout(() => populatePackages(serviceSelect?.value || ''), 0));

function setFormMessage(message, type = "info") {
  if (!formHelp) return;
  formHelp.textContent = message;
  formHelp.classList.remove("success", "error");
  if (type === "success") formHelp.classList.add("success");
  if (type === "error") formHelp.classList.add("error");
}

function submissionId() {
  if (window.crypto?.randomUUID) return crypto.randomUUID();
  return "pose-" + Date.now() + "-" + Math.random().toString(16).slice(2);
}

// V2.3 review step: customers explicitly confirm their summary before the existing submission runs.
const poseReviewDialog = document.getElementById('poseReviewDialog');
const poseReviewFields = document.getElementById('poseReviewFields');
let poseReviewApproved = false;
const reviewFieldNames = [
  ['name', 'Client'], ['contact', 'Mobile / Messenger'], ['email', 'Email'],
  ['date', 'Event date'], ['type', 'Event type'], ['location', 'Venue / location'],
  ['service', 'Service'], ['package', 'Selected package'], ['addons', 'Requested add-ons'],
  ['extraHours', 'Extra hours']
];
function populatePoseReview() {
  if (!form || !poseReviewFields) return;
  const data = new FormData(form);
  const rows = reviewFieldNames.map(([key, label]) => {
    let value = String(data.get(key) || '').trim();
    if (key === 'date' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
      const [year, month, day] = value.split('-').map(Number);
      value = new Intl.DateTimeFormat('en-PH', {year:'numeric',month:'long',day:'numeric'}).format(new Date(year,month-1,day));
    }
    if (key === 'extraHours') value = value === '0' || !value ? 'None' : value;
    if (key === 'addons' && !value) value = 'None';
    if (!value) value = 'Not provided';
    return [label, value];
  });
  poseReviewFields.replaceChildren();
  rows.forEach(([label, value]) => {
    const dt = document.createElement('dt'); dt.textContent = label;
    const dd = document.createElement('dd'); dd.textContent = value;
    poseReviewFields.append(dt, dd);
  });
  document.getElementById('poseReviewTotal').textContent = String(data.get('estimate') || 'Price on request');
}
form?.addEventListener('input', () => { poseReviewApproved = false; });
form?.addEventListener('change', () => { poseReviewApproved = false; });
document.getElementById('poseReviewEdit')?.addEventListener('click', () => poseReviewDialog?.close());
document.getElementById('poseReviewConfirm')?.addEventListener('click', () => {
  if (!form || !form.reportValidity()) { poseReviewDialog?.close(); return; }
  poseReviewApproved = true;
  poseReviewDialog?.close();
  form.requestSubmit();
});
poseReviewDialog?.addEventListener('close', () => {
  if (!poseReviewApproved) submitBtn?.focus();
});

form?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!form.reportValidity()) return;
  if (!poseReviewApproved && poseReviewDialog?.showModal) {
    populatePoseReview();
    poseReviewDialog.showModal();
    poseTrack('pose_inquiry_review_opened', {package_name: packageSelect?.value || ''});
    return;
  }
  poseReviewApproved = false; // A later attempt must always require a fresh review.

  const endpoint = window.POSE_INQUIRY?.endpoint?.trim();
  if (!endpoint) {
    setFormMessage(
      "Online inquiry is not configured yet. Please message POSE on Facebook instead.",
      "error",
    );
    return;
  }

  const data = new FormData(form);
  if (data.get("website")) return; // honeypot

  const payload = new URLSearchParams();
  for (const [key, value] of data.entries()) payload.append(key, String(value));
  payload.set("submissionId", submissionId());
  payload.set("source", location.href.split("#")[0]);
  payload.set("submittedAt", new Date().toISOString());

  const original = submitBtn.textContent;
  submitBtn.disabled = true;
  submitBtn.textContent = "Sending…";
  setFormMessage("Sending your inquiry…");

  try {
    let response;
    try {
      response = await fetch(endpoint, {
        method: "POST",
        body: payload,
        redirect: "follow",
      });
      if (response.type !== "opaque" && !response.ok)
        throw new Error("HTTP " + response.status);
      if (response.type !== "opaque") {
        const result = await response.json().catch(() => null);
        if (result && result.ok === false)
          throw new Error(result.error || "Submission failed");
      }
    } catch (firstError) {
      // Apps Script may not expose CORS response headers in every hosting setup.
      // A no-cors retry still delivers the form to the Web App.
      await fetch(endpoint, { method: "POST", body: payload, mode: "no-cors" });
    }

    // A no-cors response is opaque and cannot prove server acceptance.
    const receiptStatus = response?.type === 'opaque' || !response ? 'unverified' : 'http_ok';
    poseTrack('pose_inquiry_posted', {package_name: String(data.get('package') || ''), receipt_status: receiptStatus});
    form.reset();
    setFormMessage(
      "Your inquiry was submitted. If you don’t receive a confirmation, please message POSE on Facebook to verify receipt.",
      "success",
    );
  } catch (err) {
    console.error("Inquiry submission failed:", err);
    setFormMessage(
      "We could not send your inquiry right now. Please try again, or message POSE Photobooth on Facebook.",
      "error",
    );
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = original;
  }
});

// Small, client-side guide to help visitors choose existing packages.
(() => {
  const goal = document.querySelector('#finderGoal');
  const budget = document.querySelector('#finderBudget');
  const result = document.querySelector('#finderResult');
  const inquire = document.querySelector('#finderInquire');
  if (!goal || !budget || !result || !inquire) return;
  const options = {
    prints: {low:['Photobooth 4R','₱2,999 · 2 hours'],mid:['Photobooth Strip','₱3,499 · 2 hours; add souvenirs'],high:['Signature Booth','₱4,999 · 2 hours; one layout']},
    roaming: {low:['Photoman Unlimited','₱4,999 · 2 hours'],mid:['Photoman Unlimited','₱4,999 · optional Video Guestbook +₱1,000'],high:['Photoman Premium','₱7,499 · 2 hours']},
    coverage: {low:['Photobooth 4R','₱2,999 · add Event Photography +₱2,500'],mid:['Photobooth Strip','₱3,499 · add Event Photography +₱2,500'],high:['Signature Booth','₱4,999 · add Event Photography +₱2,500']},
    video: {low:['360 Package','₱12,000 · 3 hours'],mid:['360 Package','₱12,000 · 3 hours'],high:['360 Package','₱12,000 · 3 hours']}
  };
  const update = () => {
    const [name, detail] = options[goal.value][budget.value];
    result.querySelector('strong').textContent = name;
    result.querySelector('span').textContent = detail;
    inquire.dataset.package = name;
    inquire.dataset.service = packageServices[name] || 'Not sure yet';
    if (goal.value === 'coverage') inquire.dataset.addPhotography = 'true'; else delete inquire.dataset.addPhotography;
  };
  goal.addEventListener('change',update); budget.addEventListener('change',update); update();
  // The delegated CTA listener handles synchronization for package recommendations.

})();


// V2.1: optional conversion events. The website does not load GA4/Meta Pixel by default.
// If an analytics platform is configured with the appropriate privacy notice/consent,
// it may listen for these dataLayer or custom events. No contact information is emitted.
function poseTrack(eventName, parameters = {}) {
  const detail = {event: eventName, ...parameters};
  window.dispatchEvent(new CustomEvent('pose:analytics', {detail}));
  if (Array.isArray(window.dataLayer)) window.dataLayer.push(detail);
}

// Accessible portfolio category buttons (the old category labels were non-interactive).
const poseGalleryFilters = document.querySelectorAll('[data-gallery-filter]');
poseGalleryFilters.forEach(button => button.addEventListener('click', () => {
  const category = button.dataset.galleryFilter;
  poseGalleryFilters.forEach(item => {
    const selected = item === button;
    item.classList.toggle('active', selected);
    item.setAttribute('aria-pressed', String(selected));
  });
  document.querySelectorAll('[data-gallery-category]').forEach(card => {
    card.hidden = category !== 'all' && card.dataset.galleryCategory !== category;
  });
  poseTrack('pose_gallery_filter', {category});
}));

document.querySelectorAll('[data-package]').forEach(link => link.addEventListener('click', () => {
  poseTrack('pose_package_inquiry_click', {package_name: link.dataset.package || 'unspecified'});
}));
document.querySelectorAll('a[href*="m.me/"], a[href*="facebook.com/pose.photobooth"]').forEach(link => {
  link.addEventListener('click', () => poseTrack('pose_messenger_click', {placement: link.className || 'link'}));
});


// V2.2: transparent, client-side indicative prices; not a payment or booking system.
(() => {
  const prices = Object.fromEntries(POSE_PACKAGES.map(p => [p.id, [p.price, p.extraHourRate]]));
  const $ = id => document.getElementById(id);
  const opt = { projector:$('addonProjector'), enclosure:$('addonEnclosure'), magnets:$('addonMagnets'), standardMagnet:$('addonStandardMagnet'), video:$('addonVideoGuestbook'), photography:$('addonPhotography') };
  const souvenir = $('quoteSouvenir');
  const signatureLayouts = $('quoteSignatureLayouts');
  const signatureFormat = $('quoteSignatureFormat');
  const souvenirPrices = {keychain50:2500,keychain100:4000,magnet50:3000,magnet100:5000};
  const souvenirLabels = {keychain50:'50 acrylic keychain souvenir sets',keychain100:'100 acrylic keychain souvenir sets',magnet50:'50 magnetic strip + acrylic keychain souvenir sets',magnet100:'100 magnetic strip + acrylic keychain souvenir sets'};
  const hours = $('quoteExtraHours');
  const format = amount => '₱' + amount.toLocaleString('en-PH');
  function updateQuote() {
    const selected = packageSelect?.value || '';
    const base = prices[selected];
    const hasPublishedPrice = Number.isFinite(base?.[0]);
    const is360 = selected === '360 Package';
    const isPhotoman = selected === 'Photoman Unlimited' || selected === 'Photoman Premium';
    const includesGuestbook = false;
    const isClassic = selected.startsWith('Photobooth ') || selected.startsWith('Strip ');
    const isSignature = selected === 'Signature Booth';
    const isPolaroid = selected === 'Photobooth Polaroid' || (isSignature && signatureFormat.value === 'Polaroid');
    const standardMagnetEligible = (isClassic && !selected.startsWith('Strip ')) || isSignature || selected === 'Studio Promo' || selected === 'AI Premium';
    const standardMagnetRate = selected === 'Studio Promo' ? 1000 : isPolaroid || selected === 'AI Premium' ? 1000 : 500;
    const standardMagnetLabel = selected === 'Studio Promo' ? '₱1,000 per 50 prints' : `₱${standardMagnetRate.toLocaleString('en-PH')} per booked hour`;
    $('standardMagnetPrice').textContent = standardMagnetLabel;
    const setAvailable = (input, available) => {input.disabled = !available; if(!available) input.checked = false;};
    setAvailable(opt.projector, Boolean(selected && hasPublishedPrice));
    setAvailable(opt.enclosure, is360);
    setAvailable(opt.magnets, isPhotoman);
    setAvailable(opt.standardMagnet, standardMagnetEligible);
    setAvailable(opt.video, Boolean(selected && hasPublishedPrice && !includesGuestbook));
    setAvailable(opt.photography, Boolean(selected && hasPublishedPrice));
    const isStrip = selected === 'Photobooth Strip' || (selected === 'Signature Booth' && signatureFormat.value === 'Strip');
    const isSouvenirBundle = /^(Strip Souvenir (50|100)|Strip Magnetic Souvenir (50|100))$/.test(selected);
    $('signatureLayoutsWrap').hidden = !isSignature;
    $('signatureFormatWrap').hidden = !isSignature;
    signatureFormat.disabled = !isSignature;
    if (!isSignature) signatureFormat.value = '4R';
    signatureLayouts.disabled = !isSignature;
    if (!isSignature) signatureLayouts.value = '0';
    // Hide unrelated add-ons entirely rather than displaying disabled controls.
    const visibleOptions = {
      projector: Boolean(selected && hasPublishedPrice),
      enclosure: is360,
      magnets: isPhotoman,
      standardMagnet: standardMagnetEligible,
      video: Boolean(selected && hasPublishedPrice && !includesGuestbook),
      photography: Boolean(selected && hasPublishedPrice)
    };
    Object.entries(opt).forEach(([key, input]) => { input.closest('.pose-quote-option').hidden = !visibleOptions[key]; });
    const relevant = $('poseRelevantAddons');
    if (relevant) relevant.hidden = !Object.values(visibleOptions).some(Boolean);
    $('souvenirQuoteWrap').hidden = !isStrip;
    $('souvenirQuantityPolicy').hidden = !((isStrip && souvenir.value) || isSouvenirBundle);
    $('poseExtraHoursWrap').hidden = !Number.isFinite(base?.[1]);
    souvenir.disabled = !isStrip;
    if (!isStrip) souvenir.value = '';
    $('souvenirQuantityPolicy').hidden = !((isStrip && souvenir.value) || isSouvenirBundle);
    const hourRate = isSignature && isPolaroid ? 2000 : base?.[1];
    hours.disabled = !Number.isFinite(hourRate);
    if (hours.disabled) hours.value = '0';
    $('quoteHourRate').textContent = Number.isFinite(hourRate)
      ? `${format(hourRate)} per additional hour of the selected primary service.`
      : 'Additional hours for this package are quoted on request.';
    let total = hasPublishedPrice ? base[0] : null;
    const additions = [];
    if (isSouvenirBundle) additions.push('Souvenir allocation included in bundle price; quantity remains fixed on extension');
    if (opt.projector.checked) {total += 2000; additions.push('Projector presentation (up to 4 hours): +₱2,000');}
    if (opt.enclosure.checked) {total += 5000; additions.push('360 LED enclosure: +₱5,000');}
    if (opt.magnets.checked) {total += 1000; additions.push('Photoman magnets / 50 prints: +₱1,000');}
    if (opt.standardMagnet.checked) {
      const bookedHours = (selected === 'AI Premium' ? 3 : 2) + (Number(hours.value) || 0);
      const magnetCharge = selected === 'Studio Promo' ? 1000 : standardMagnetRate * bookedHours;
      total += magnetCharge;
      additions.push(`Magnet upgrade (${selected === 'Studio Promo' ? '50 prints' : bookedHours + ' booked hours'}): +${format(magnetCharge)}`);
    }
    if (opt.video.checked) {total += 1000; additions.push('Video Guestbook (standard screen, digital recordings): +₱1,000');}
    if (opt.photography.checked) {total += 2500; additions.push('Event Photography (up to 3 hours): +₱2,500');}
    if (isStrip && souvenirPrices[souvenir.value]) {
      const cost = souvenirPrices[souvenir.value];
      total += cost;
      additions.push(`${souvenirLabels[souvenir.value]}: +${format(cost)}`);
    }
    if (isSignature) additions.push(`Signature print format: ${signatureFormat.value}`);
    if (isSignature && Number(signatureLayouts.value) > 0) {
      const extraLayouts = Number(signatureLayouts.value);
      total += extraLayouts * 500;
      additions.push(`${extraLayouts} additional Signature layout(s): +${format(extraLayouts * 500)}`);
    }
    const count = Number(hours.value) || 0;
    if (count && Number.isFinite(hourRate)) {total += count * hourRate; additions.push(`${count} additional hour(s): +${format(count * hourRate)}`);}
    $('quoteTotal').textContent = total == null ? (selected ? 'Price on request' : 'Select a package') : format(total);
    $('quoteDetails').textContent = total == null ? 'Choose a priced package to calculate an estimate.' : `${posePackageById.get(selected)?.label || selected}: ${format(base[0])}${additions.length ? ' · ' + additions.join(' · ') : ' · No extras selected'}`;
    $('quoteAddonsField').value = additions.join('; ');
    $('quoteEstimateField').value = total == null ? 'Price on request' : format(total);
    $('quoteExtraHoursField').value = String(count);
  }
  packageSelect?.addEventListener('change', updateQuote);
  Object.values(opt).forEach(el => el.addEventListener('change', updateQuote));
  hours?.addEventListener('change', updateQuote);
  souvenir?.addEventListener('change', updateQuote);
  signatureLayouts?.addEventListener('change', updateQuote);
  signatureFormat?.addEventListener('change', updateQuote);
  // Finder buttons also populate the package; their handlers are registered earlier.
  form?.addEventListener('reset', () => setTimeout(updateQuote, 0));
  updateQuote();
})();
