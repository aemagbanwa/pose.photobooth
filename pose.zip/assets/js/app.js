// Shared header menu behavior is owned by assets/js/partials.js.
const yearEl = document.querySelector("#year");
if (yearEl) yearEl.textContent = new Date().getFullYear();

document.querySelectorAll(".package-carousel-shell").forEach((shell) => {
  const carousel = shell.querySelector(".package-carousel");
  const cards = carousel?.querySelectorAll(".price-card");
  if (!carousel || !cards?.length) return;
  const controls = [...shell.querySelectorAll("[data-carousel-direction]")];
  const status = shell.querySelector(".carousel-status");
  const updateCarouselState = () => {
    const maxScroll = carousel.scrollWidth - carousel.clientWidth;
    const atStart = carousel.scrollLeft <= 2;
    const atEnd = carousel.scrollLeft >= maxScroll - 2;
    controls.forEach((button) => {
      const isNext = button.dataset.carouselDirection === "next";
      button.disabled = isNext ? atEnd : atStart;
      button.setAttribute("aria-disabled", String(button.disabled));
    });
    const step = cards[0].getBoundingClientRect().width + 18;
    const current = Math.min(
      cards.length,
      Math.max(1, Math.round(carousel.scrollLeft / step) + 1),
    );
    if (status) status.textContent = `Package ${current} of ${cards.length}`;
  };
  controls.forEach((button) =>
    button.addEventListener("click", () => {
      const direction = button.dataset.carouselDirection === "next" ? 1 : -1;
      const distance = cards[0].getBoundingClientRect().width + 18;
      carousel.scrollBy({ left: direction * distance, behavior: "smooth" });
    }),
  );
  carousel.addEventListener("scroll", updateCarouselState, { passive: true });
  window.addEventListener("resize", updateCarouselState);
  updateCarouselState();
});

// Keep same-page navigation reliable during local preview and on the live site.
document.querySelectorAll('a[href^="#"]').forEach((a) =>
  a.addEventListener("click", (e) => {
    const id = a.getAttribute("href").slice(1);
    const target = document.getElementById(id);
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView({ behavior: "smooth", block: "start" });
    try {
      history.replaceState(null, "", "#" + id);
    } catch (_) {}
  }),
);

const form = document.querySelector("#leadForm");
const formHelp = document.querySelector("#formHelp");
const submitBtn = form?.querySelector('button[type="submit"]');
const packageSelect = document.querySelector("#packageSelect");

document.querySelectorAll("[data-package]").forEach((link) =>
  link.addEventListener("click", () => {
    if (packageSelect) packageSelect.value = link.dataset.package;
    const serviceSelect = form?.querySelector('[name="service"]');
    if (serviceSelect && link.dataset.service) serviceSelect.value = link.dataset.service;
    else if (serviceSelect?.value === "AI Photobooth") {
      serviceSelect.value = link.dataset.package.startsWith("Photoman") ? "Photoman" : link.dataset.package === "360 Package" ? "360 Video Booth" : link.dataset.package === "Studio Promo" ? "Onsite Photo Studio" : link.dataset.package === "Signature Booth" ? "Premium Photobooth" : "Classic Photobooth";
    }
  }),
);

function setFormMessage(message, type = "info") {
  if (!formHelp) return;
  formHelp.textContent = message;
  formHelp.classList.remove("success", "error");
  if (type === "success") formHelp.classList.add("success");
  if (type === "error") formHelp.classList.add("error");
}

function submissionId() {
  if (window.crypto?.randomUUID) return crypto.randomUUID();
  return "pose-" + Date.now() + "-" + Math.random().toString(16).slice(2);
}

form?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!form.reportValidity()) return;

  const endpoint = window.POSE_INQUIRY?.endpoint?.trim();
  if (!endpoint) {
    setFormMessage(
      "Online inquiry is not configured yet. Please message POSE on Facebook instead.",
      "error",
    );
    return;
  }

  const data = new FormData(form);
  if (data.get("website")) return; // honeypot

  const payload = new URLSearchParams();
  for (const [key, value] of data.entries()) payload.append(key, String(value));
  payload.set("submissionId", submissionId());
  payload.set("source", location.href.split("#")[0]);
  payload.set("submittedAt", new Date().toISOString());

  const original = submitBtn.textContent;
  submitBtn.disabled = true;
  submitBtn.textContent = "Sending…";
  setFormMessage("Sending your inquiry…");

  try {
    let response;
    try {
      response = await fetch(endpoint, {
        method: "POST",
        body: payload,
        redirect: "follow",
      });
      if (response.type !== "opaque" && !response.ok)
        throw new Error("HTTP " + response.status);
      if (response.type !== "opaque") {
        const result = await response.json().catch(() => null);
        if (result && result.ok === false)
          throw new Error(result.error || "Submission failed");
      }
    } catch (firstError) {
      // Apps Script may not expose CORS response headers in every hosting setup.
      // A no-cors retry still delivers the form to the Web App.
      await fetch(endpoint, { method: "POST", body: payload, mode: "no-cors" });
    }

    form.reset();
    setFormMessage(
      "Inquiry sent. Thank you! POSE has received your event details. If you provided an email address, a confirmation has also been sent there.",
      "success",
    );
  } catch (err) {
    console.error("Inquiry submission failed:", err);
    setFormMessage(
      "We could not send your inquiry right now. Please try again, or message POSE Photobooth on Facebook.",
      "error",
    );
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = original;
  }
});

// Keep AI inquiries complete whether visitors use a CTA or the form directly.
const serviceSelect = form?.querySelector('[name="service"]');
serviceSelect?.addEventListener('change', () => {
  if (serviceSelect.value === 'AI Photobooth' && packageSelect) packageSelect.value = 'AI Photobooth';
  else if (packageSelect?.value === 'AI Photobooth') packageSelect.value = '';
});
packageSelect?.addEventListener('change', () => {
  if (packageSelect.value === 'AI Photobooth' && serviceSelect) serviceSelect.value = 'AI Photobooth';
  else if (serviceSelect?.value === 'AI Photobooth') serviceSelect.value = '';
});
