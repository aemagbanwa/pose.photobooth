const ROOT_FOLDER_ID = '13TDUiu_rKxJJrdkQTGhn-o2nVFv6-ZjI';
const CACHE_SECONDS = 300;
const CONFIG_SHEET_ID_PROPERTY = 'POSE_GALLERY_CONFIG_SHEET_ID';
const CONFIG_SHEET_ID = '1F6c8ndtnvJ6F_40JGO9kj5VfbkQMIxLBIgXegXMt2vU';
const PIN_SALT_PROPERTY = 'POSE_GALLERY_PIN_SALT';
const CONFIG_SHEET_NAME = 'Events';
const GALLERY_CACHE_KEY = 'pose-gallery-index-v7';
let requestConfigMemo_;
const CONFIG_HEADERS = [
  'Folder ID',
  'Event Name',
  'New PIN',
  'PIN Hash',
  'PIN Enabled',
  'Downloads Enabled',
  'Expiry Date',
  'Cover File ID',
  'Updated At'
];

function doGet(request) {
  try {
    // Apps Script deployments and installable triggers can have separate cache
    // state. Read the private Sheet once per request so PIN changes are always
    // authoritative, while still avoiding one Sheet read per event folder.
    requestConfigMemo_ = undefined;
    const params = (request && request.parameter) || {};
    if (params.eventId) return unlockEvent_(params.eventId, params.pin || '');

    const cache = CacheService.getScriptCache();
    const cached = params.refresh === '1' ? null : cache.get(GALLERY_CACHE_KEY);
    if (cached) return jsonResponse_(JSON.parse(cached));

    const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
    const events = [];
    const folders = root.getFolders();
    while (folders.hasNext()) {
      const event = buildEvent_(folders.next(), false, false);
      if (event && event.itemCount) events.push(event);
    }

    const rootItems = readMedia_(root, false);
    if (rootItems.length) {
      events.push(eventPayload_({ folder: root, details: { eventName: 'Recent celebrations', eventDate: '' }, settings: { pinEnabled: false, downloadsEnabled: true }, items: rootItems, protectedView: false, includeItems: false }));
    }

    events.sort(function (a, b) { return String(b.eventDate).localeCompare(String(a.eventDate)); });
    const payload = { ok: true, updatedAt: new Date().toISOString(), events: events };
    // Apps Script cache entries are limited in size. A gallery with many photos
    // can exceed that limit, but caching must never make a valid feed fail.
    try {
      cache.put(GALLERY_CACHE_KEY, JSON.stringify(payload), CACHE_SECONDS);
    } catch (cacheError) {
      console.warn('POSE gallery cache skipped: ' + cacheError.message);
    }
    return jsonResponse_(payload);
  } catch (error) {
    console.error(error);
    return jsonResponse_({ ok: false, updatedAt: new Date().toISOString(), events: [], message: 'The gallery is temporarily unavailable.' });
  }
}

function unlockEvent_(folderId, suppliedPin) {
  const isRootFolder = folderId === ROOT_FOLDER_ID;
  if (!isRootFolder && !isEventFolder_(folderId)) {
    return jsonResponse_({ ok: false, code: 'EVENT_NOT_FOUND', message: 'That event could not be found.' });
  }
  const folder = DriveApp.getFolderById(folderId);
  const settings = isRootFolder
    ? { pinEnabled: false, coverFileId: '', downloadsEnabled: true, expires: '' }
    : settingsFor_(folderId);
  if (settings.pinEnabled && (!settings.pinHash || !secureEquals_(hashPin_(suppliedPin), settings.pinHash))) {
    return jsonResponse_({ ok: false, code: 'INVALID_PIN', message: 'That PIN is not correct.' });
  }
  return jsonResponse_({ ok: true, event: buildEvent_(folder, true, true) });
}

function buildEvent_(folder, unlocked, includeItems) {
  const isRootFolder = folder.getId() === ROOT_FOLDER_ID;
  const settings = isRootFolder
    ? { pinEnabled: false, coverFileId: '', downloadsEnabled: true, expires: '' }
    : settingsFor_(folder.getId());
  if (settings.expires && new Date(settings.expires + 'T23:59:59') < new Date()) return null;
  const items = includeItems ? cachedEventMedia_(folder) : readMedia_(folder, false);
  return eventPayload_({
    folder: folder,
    details: isRootFolder
      ? { eventName: 'Recent celebrations', eventDate: '' }
      : parseEventFolder_(folder.getName()),
    settings: settings,
    items: items,
    protectedView: Boolean(settings.pinEnabled) && !unlocked,
    includeItems: includeItems
  });
}

function cachedEventMedia_(folder) {
  const cache = CacheService.getScriptCache();
  const key = 'pose-gallery-media-v1-' + folder.getId();
  const cached = cache.get(key);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch (error) {
      cache.remove(key);
    }
  }

  const items = readMedia_(folder, true);
  try {
    cache.put(key, JSON.stringify(items), CACHE_SECONDS);
  } catch (cacheError) {
    console.warn('POSE gallery event cache skipped: ' + cacheError.message);
  }
  return items;
}

function eventPayload_(context) {
  const cover = selectCover_(context.items, context.settings.coverFileId);
  const photoCount = context.items.filter(function (item) { return item.mediaType === 'image'; }).length;
  const videoCount = context.items.filter(function (item) { return item.mediaType === 'video'; }).length;
  const payload = {
    id: context.folder.getId(),
    eventName: context.details.eventName,
    eventDate: context.details.eventDate,
    eventType: detectEventType_(context.details.eventName),
    locked: context.protectedView,
    downloadsEnabled: context.settings.downloadsEnabled !== false,
    coverUrl: cover ? driveThumbnailUrl_(cover.id, 640) : '',
    itemCount: context.items.length,
    photoCount: photoCount,
    videoCount: videoCount
  };
  if (context.includeItems) payload.items = context.protectedView ? [] : context.items;
  return payload;
}

function settingsFor_(folderId) {
  const config = galleryConfig_();
  const configured = (config && config[folderId]) || {};
  return {
    pinHash: String(configured.pinHash || ''),
    // If the private configuration cannot be read, lock event folders rather
    // than accidentally exposing a protected gallery.
    pinEnabled: config === null || configured.pinEnabled === true,
    coverFileId: String(configured.coverFileId || ''),
    downloadsEnabled: configured.downloadsEnabled !== false,
    expires: String(configured.expires || '')
  };
}

/**
 * Run once from the Apps Script editor. It creates a private configuration
 * spreadsheet in the script owner's Drive and returns its URL.
 */
function setupGalleryConfig() {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const properties = PropertiesService.getScriptProperties();
    let spreadsheet;
    const existingId = properties.getProperty(CONFIG_SHEET_ID_PROPERTY);
    if (existingId) {
      try {
        spreadsheet = SpreadsheetApp.openById(existingId);
      } catch (error) {
        console.warn('Existing gallery configuration could not be opened; creating a new one.');
      }
    }

    if (!spreadsheet) {
      spreadsheet = SpreadsheetApp.create('POSE Gallery Configuration');
      properties.setProperty(CONFIG_SHEET_ID_PROPERTY, spreadsheet.getId());
    }
    if (!properties.getProperty(PIN_SALT_PROPERTY)) {
      properties.setProperty(PIN_SALT_PROPERTY, Utilities.getUuid() + Utilities.getUuid());
    }

    const sheet = prepareConfigSheet_(spreadsheet);
    syncConfigRows_(sheet);
    installConfigTrigger_(spreadsheet);
    clearGalleryCache_();
    console.log('POSE Gallery configuration: ' + spreadsheet.getUrl());
    return spreadsheet.getUrl();
  } finally {
    lock.releaseLock();
  }
}

/** Run after adding Drive event folders so they appear in the config sheet. */
function refreshGalleryConfig() {
  const spreadsheet = configSpreadsheet_();
  if (!spreadsheet) throw new Error('Run setupGalleryConfig first.');
  const sheet = prepareConfigSheet_(spreadsheet);
  syncConfigRows_(sheet);
  clearGalleryCache_();
  return spreadsheet.getUrl();
}

/** Installed spreadsheet trigger; converts entered PINs to salted hashes. */
function onGalleryConfigEdit(event) {
  if (!event || !event.range || event.range.getSheet().getName() !== CONFIG_SHEET_NAME) return;
  const range = event.range;
  if (range.getRow() < 2) return;
  const sheet = range.getSheet();
  const firstRow = range.getRow();
  const lastRow = range.getLastRow();
  const firstColumn = range.getColumn();
  const lastColumn = range.getLastColumn();

  if (firstColumn <= 3 && lastColumn >= 3) {
    for (let row = firstRow; row <= lastRow; row += 1) {
      const pinCell = sheet.getRange(row, 3);
      const newPin = String(pinCell.getDisplayValue() || '').trim();
      if (!newPin) continue;
      sheet.getRange(row, 4).setValue(hashPin_(newPin));
      sheet.getRange(row, 5).setValue(true);
      pinCell.clearContent();
    }
  }

  sheet.getRange(firstRow, 9, lastRow - firstRow + 1, 1).setValue(new Date());
  clearGalleryCache_();
}

function galleryConfig_() {
  if (requestConfigMemo_ !== undefined) return requestConfigMemo_;

  const spreadsheet = configSpreadsheet_();
  if (!spreadsheet) {
    requestConfigMemo_ = null;
    return requestConfigMemo_;
  }
  const sheet = spreadsheet.getSheetByName(CONFIG_SHEET_NAME);
  if (!sheet || sheet.getLastRow() < 2) {
    requestConfigMemo_ = {};
    return requestConfigMemo_;
  }

  const values = sheet.getRange(2, 1, sheet.getLastRow() - 1, CONFIG_HEADERS.length).getValues();
  const config = {};
  values.forEach(function (row) {
    const folderId = String(row[0] || '').trim();
    // The first row is authoritative. This prevents old duplicate rows farther
    // down the Sheet from silently overriding the visible configuration.
    if (!folderId || Object.prototype.hasOwnProperty.call(config, folderId)) return;
    config[folderId] = {
      pinHash: String(row[3] || ''),
      pinEnabled: checkboxValue_(row[4]),
      downloadsEnabled: row[5] === '' ? true : checkboxValue_(row[5]),
      expires: dateValue_(row[6]),
      coverFileId: String(row[7] || '').trim()
    };
  });
  requestConfigMemo_ = config;
  return requestConfigMemo_;
}

function configSpreadsheet_() {
  // Keep the non-secret configuration document location stable across web-app
  // versions. PINs themselves remain only as salted hashes in the private Sheet.
  const id = CONFIG_SHEET_ID || PropertiesService.getScriptProperties().getProperty(CONFIG_SHEET_ID_PROPERTY);
  if (!id) return null;
  try {
    return SpreadsheetApp.openById(id);
  } catch (error) {
    console.error('POSE Gallery configuration is unavailable: ' + error.message);
    return null;
  }
}

function prepareConfigSheet_(spreadsheet) {
  let sheet = spreadsheet.getSheetByName(CONFIG_SHEET_NAME);
  if (!sheet) {
    sheet = spreadsheet.getSheets()[0];
    sheet.setName(CONFIG_SHEET_NAME);
  }
  sheet.getRange(1, 1, 1, CONFIG_HEADERS.length).setValues([CONFIG_HEADERS]);
  sheet.setFrozenRows(1);
  sheet.getRange('E2:F').insertCheckboxes();
  sheet.getRange('G2:G').setNumberFormat('yyyy-mm-dd');
  sheet.getRange('I2:I').setNumberFormat('yyyy-mm-dd hh:mm:ss');
  sheet.hideColumns(4);
  sheet.autoResizeColumns(1, CONFIG_HEADERS.length);
  return sheet;
}

function syncConfigRows_(sheet) {
  const existing = {};
  if (sheet.getLastRow() > 1) {
    sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getValues().forEach(function (row, index) {
      const id = String(row[0] || '').trim();
      if (id && !existing[id]) existing[id] = index + 2;
    });
  }

  const folders = DriveApp.getFolderById(ROOT_FOLDER_ID).getFolders();
  const newRows = [];
  while (folders.hasNext()) {
    const folder = folders.next();
    const id = folder.getId();
    if (existing[id]) {
      sheet.getRange(existing[id], 2).setValue(parseEventFolder_(folder.getName()).eventName);
    } else {
      newRows.push([id, parseEventFolder_(folder.getName()).eventName, '', '', false, true, '', '', new Date()]);
    }
  }
  if (newRows.length) {
    sheet.getRange(sheet.getLastRow() + 1, 1, newRows.length, CONFIG_HEADERS.length).setValues(newRows);
  }
}

function installConfigTrigger_(spreadsheet) {
  const exists = ScriptApp.getProjectTriggers().some(function (trigger) {
    return trigger.getHandlerFunction() === 'onGalleryConfigEdit';
  });
  if (!exists) ScriptApp.newTrigger('onGalleryConfigEdit').forSpreadsheet(spreadsheet).onEdit().create();
}

function hashPin_(pin) {
  const properties = PropertiesService.getScriptProperties();
  let salt = properties.getProperty(PIN_SALT_PROPERTY);
  if (!salt) {
    salt = Utilities.getUuid() + Utilities.getUuid();
    properties.setProperty(PIN_SALT_PROPERTY, salt);
  }
  const bytes = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    salt + ':' + String(pin),
    Utilities.Charset.UTF_8
  );
  return bytes.map(function (value) {
    const normalized = value < 0 ? value + 256 : value;
    return ('0' + normalized.toString(16)).slice(-2);
  }).join('');
}

function secureEquals_(left, right) {
  left = String(left || '');
  right = String(right || '');
  let mismatch = left.length ^ right.length;
  const length = Math.max(left.length, right.length);
  for (let index = 0; index < length; index += 1) {
    mismatch |= (left.charCodeAt(index % Math.max(left.length, 1)) || 0)
      ^ (right.charCodeAt(index % Math.max(right.length, 1)) || 0);
  }
  return mismatch === 0;
}

function checkboxValue_(value) {
  return value === true || String(value).toLowerCase() === 'true';
}

function dateValue_(value) {
  if (!value) return '';
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value.getTime())) {
    return Utilities.formatDate(value, Session.getScriptTimeZone(), 'yyyy-MM-dd');
  }
  return String(value).trim();
}

function isEventFolder_(folderId) {
  try {
    const rootId = DriveApp.getFolderById(ROOT_FOLDER_ID).getId();
    const parents = DriveApp.getFolderById(folderId).getParents();
    while (parents.hasNext()) {
      if (parents.next().getId() === rootId) return true;
    }
  } catch (error) {
    return false;
  }
  return false;
}

function clearGalleryCache_() {
  const cache = CacheService.getScriptCache();
  cache.remove(GALLERY_CACHE_KEY);
  requestConfigMemo_ = undefined;
}

function readMedia_(folder, includeDetails) {
  const items = [];
  const files = folder.getFiles();
  while (files.hasNext()) {
    const file = files.next();
    const mimeType = file.getMimeType() || '';
    const isImage = mimeType.indexOf('image/') === 0;
    const isVideo = mimeType.indexOf('video/') === 0;
    if (!isImage && !isVideo) continue;
    const id = file.getId();
    const item = {
      id: id,
      name: file.getName(),
      mimeType: mimeType,
      mediaType: isVideo ? 'video' : 'image'
    };
    if (includeDetails) {
      item.description = file.getDescription() || '';
      item.thumbnailUrl = driveThumbnailUrl_(id, 240);
      item.imageUrl = isImage ? driveThumbnailUrl_(id, 1800) : '';
      item.previewUrl = isVideo ? 'https://drive.google.com/file/d/' + encodeURIComponent(id) + '/preview' : '';
      item.originalUrl = 'https://drive.google.com/file/d/' + encodeURIComponent(id) + '/view';
      item.downloadUrl = 'https://drive.google.com/uc?export=download&id=' + encodeURIComponent(id);
      item.modifiedTime = file.getLastUpdated().toISOString();
    }
    items.push(item);
  }
  if (includeDetails) {
    items.sort(function (a, b) { return String(b.modifiedTime).localeCompare(String(a.modifiedTime)); });
  }
  return items;
}

function driveThumbnailUrl_(fileId, size) {
  return 'https://drive.google.com/thumbnail?id=' + encodeURIComponent(fileId) + '&sz=w' + size;
}

function selectCover_(items, configuredId) {
  return items.find(function (item) { return configuredId && item.id === configuredId; })
    || items.find(function (item) { return /^cover[\s_.-]/i.test(item.name) && item.mediaType === 'image'; })
    || items.find(function (item) { return item.mediaType === 'image'; })
    || items[0] || null;
}

function parseEventFolder_(folderName) {
  const match = String(folderName).trim().match(/^(\d{4})(\d{2})(\d{2})[\s_-]+(.+)$/);
  return match ? { eventName: match[4].trim(), eventDate: match[1] + '-' + match[2] + '-' + match[3] } : { eventName: String(folderName).trim(), eventDate: '' };
}

function detectEventType_(eventName) {
  const name = String(eventName).toLowerCase();
  if (/birthday|bday|\d+(st|nd|rd|th)/.test(name)) return 'birthday';
  if (/wedding|nuptial|bride|groom/.test(name)) return 'wedding';
  if (/debut|18th/.test(name)) return 'debut';
  if (/corporate|company|year[- ]?end|christmas party|team/.test(name)) return 'corporate';
  return 'other';
}

function jsonResponse_(payload) {
  return ContentService.createTextOutput(JSON.stringify(payload)).setMimeType(ContentService.MimeType.JSON);
}
